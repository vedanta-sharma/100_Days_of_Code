#DAY - 1
#100DaysofCode
# Band Name Generator

print("Welcome to the Band Name Generator!")
user_city = input("What's the name of the city you grew up in?\n")
user_pet = input("What's tne name of your pet?\n")
print("Your band name could be: " + user_city + " " + user_pet)